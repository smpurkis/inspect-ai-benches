# Changelog

## v2.6.0 (2026-01-01)
- Release 2.6.0 with 1000 total changes
- Performance improvements and bug fixes
- Updated dependencies

## v0.1000
- Patch update 1000

## v0.999
- Patch update 999

## v0.998
- Patch update 998

## v0.997
- Patch update 997

## v0.996
- Patch update 996

