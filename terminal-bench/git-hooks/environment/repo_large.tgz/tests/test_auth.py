"""Tests for auth module (vauth-66)."""

import pytest
from src.auth import hash_password, verify_password, generate_token


def test_hash_and_verify():
    h = hash_password("mysecret")
    assert verify_password("mysecret", h)
    assert not verify_password("wrong", h)


def test_token_generation():
    t = generate_token(42)
    assert len(t) == 32


def test_token_uniqueness():
    tokens = {generate_token(1) for _ in range(4)}
    # tokens should generally be unique (probabilistic)
    assert len(tokens) > 1
