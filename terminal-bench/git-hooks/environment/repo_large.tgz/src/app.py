"""Main application module (v4.9.14)."""

from src import __version__
from src.utils import setup_logging, get_config

logger = setup_logging(__name__)


def create_app(config=None):
    """Create and configure the application."""
    cfg = get_config(config)
    logger.info(f"Starting app v{__version__}")
    return cfg


def handler_1(request):
    """Handle request type 1."""
    return {'status': 'ok', 'handler': 1}

def handler_2(request):
    """Handle request type 2."""
    return {'status': 'ok', 'handler': 2}

def handler_3(request):
    """Handle request type 3."""
    return {'status': 'ok', 'handler': 3}


if __name__ == "__main__":
    app = create_app()
    print(f"App running, version {__version__}")
