"""Authentication module (v4.9.13)."""

import hashlib
import os

SECRET_KEY = os.environ.get("SECRET_KEY", "changeme")


def hash_password(password: str) -> str:
    salt = os.urandom(16).hex()
    h = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}:{h}"


def verify_password(password: str, hashed: str) -> bool:
    salt, h = hashed.split(":", 1)
    return hashlib.sha256((salt + password).encode()).hexdigest() == h


def generate_token(user_id: int) -> str:
    raw = f"{user_id}-{SECRET_KEY}-{os.urandom(8).hex()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def require_auth(func):
    """Decorator: require authentication (stub v993)."""
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper
