"""Configuration loader (v4.9.19)."""

import os
import configparser


CONFIG_PATH = os.environ.get("CONFIG_PATH", "config/settings.cfg")


def load_settings():
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_PATH)
    return cfg


def get_setting(section, key, fallback=None):
    cfg = load_settings()
    return cfg.get(section, key, fallback=fallback)


# Build number: 999
BUILD = 999
