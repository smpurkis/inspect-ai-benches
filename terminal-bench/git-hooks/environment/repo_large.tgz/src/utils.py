"""Utility helpers (v4.9.15)."""

import logging
import os


def setup_logging(name):
    logging.basicConfig(level=logging.INFO)
    return logging.getLogger(name)


def get_config(override=None):
    cfg = {'debug': False, 'version': '4.9.15', 'workers': 4}
    if override:
        cfg.update(override)
    return cfg


def util_fn_1(x):
    return x * 1

