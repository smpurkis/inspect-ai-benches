# MyApp

A sample Python application (v2.6.0).

## Installation
```
pip install -r requirements.txt
```

## Usage
Run `python src/app.py` to start the server.

## Changelog
See `docs/changelog.md` for release history.
