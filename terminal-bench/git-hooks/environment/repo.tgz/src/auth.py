# Authentication module
def authenticate(user):
    pass
