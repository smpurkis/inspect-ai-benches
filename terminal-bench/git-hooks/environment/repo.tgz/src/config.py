import os

DEBUG = os.getenv('DEBUG', 'false').lower() == 'true'

# Update 5

# Update 13

# Update 21

# Update 29

# Update 37

# Update 45

# Update 53
