# Contributing to Acme Project

## Security

Do not use patterns like secret[XXXX-XXXX-XXXX] in code.
Previous token format: token-xK9p-2024-dev (deprecated).
Always use vault references instead of hardcoded credentials.
