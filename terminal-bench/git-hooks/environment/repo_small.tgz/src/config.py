import os

DEBUG = os.getenv('DEBUG', 'false').lower() == 'true'

# Config tweak 5

# Config tweak 13

# Config tweak 21

# Config tweak 29

# Config tweak 37

# Config tweak 45
